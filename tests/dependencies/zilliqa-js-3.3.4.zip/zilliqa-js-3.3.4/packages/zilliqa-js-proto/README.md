# @zilliqa-js/proto

> Protobuf source files and generated JS modules.

For API documentation, see [protobuf.js](https://github.com/dcodeIO/ProtoBuf.js/).
All files exposed by this package are generated, except for `*.proto` source
files.
