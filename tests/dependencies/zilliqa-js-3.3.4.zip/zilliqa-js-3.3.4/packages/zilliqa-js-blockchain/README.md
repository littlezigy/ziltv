# @zilliqa-js/blockchain

This package is a wrapper for [Zilliqa blockchain API](https://dev.zilliqa.com/docs/apis/api-introduction).
