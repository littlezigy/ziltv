# Examples

⚠️ **NOTICE:** All examples have been moved as standalone repository to [here](https://github.com/Zilliqa/Zilliqa-JavaScript-Library-Examples).
